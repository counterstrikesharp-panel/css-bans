<!DOCTYPE html>
<html lang="en" data-mdb-theme="light">
<body>
<!-- Header -->
<?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Sidebar -->
<?php echo $__env->make('partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--Main layout-->
<main style="margin-top: 58px">
    <div class="container pt-4">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    <!-- Footer -->
    <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</main>

<!-- MDB -->
<?php echo app('Illuminate\Foundation\Vite')(['resources/js/mdb.umd.min.js']); ?>
<!-- Custom scripts -->
<?php echo $__env->make('partials.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div id="loader">
    <div class="spinner-border text-primary" role="status">
        <span class="visually-hidden">Loading...</span>
    </div>
</div>
</body>
</html>
<?php /**PATH /www/wwwroot/css.matchclub.xyz/resources/views/layouts/app.blade.php ENDPATH**/ ?>