<?php use App\Helpers\PermissionsHelper; ?>
<div style="height: 400px; overflow-y: auto;">
    <table id="server_players" class="table">
        <thead>
        <tr>
            <th>ID</th>
            <th width="20">Name</th>
            <th>Frags</th>
            <th>Time</th>
            <th>Actions</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($player['Name']); ?></td>
                <td><?php echo e($player['Frags']); ?></td>
                <td><?php echo e($player['TimeF']); ?></td>
                <td>
                    <!-- Icon for kick action -->
                    <?php if(PermissionsHelper::hasKickPermission()): ?>
                        <a title="kick" href="#" class="action-icon player" data-action="kick" data-server-id="<?php echo e($server->id); ?>" data-player-name="<?php echo e($player['Name']); ?>"><i class="fas fa-user-times"></i></a>
                    <?php endif; ?>
                    <?php if(PermissionsHelper::hasMutePermission()): ?>
                    <!-- Icon for mute action -->
                        <a title="mute" href="#" class="action-icon player" data-action="mute" data-server-id="<?php echo e($server->id); ?>" data-player-name="<?php echo e($player['Name']); ?>"><i class="fas fa-volume-mute"></i></a>
                    <?php endif; ?>
                    <?php if(PermissionsHelper::hasBanPermission()): ?>
                    <!-- Icon for ban action -->
                        <a title="ban" href="#" class="action-icon player" data-action="ban" data-server-id="<?php echo e($server->id); ?>" data-player-name="<?php echo e($player['Name']); ?>"><i class="fas fa-ban"></i></a>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<?php /**PATH /www/wwwroot/css.matchclub.xyz/resources/views/admin/servers/players.blade.php ENDPATH**/ ?>