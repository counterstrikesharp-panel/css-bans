$(document).ready(function () {
      $('#server_ids').select2({
        placeholder: 'Select Servers',
    });
});
