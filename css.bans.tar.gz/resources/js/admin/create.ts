$(document).ready(function() {
    $('#server_id').select2({
        placeholder: 'Select Servers',
    });
})
