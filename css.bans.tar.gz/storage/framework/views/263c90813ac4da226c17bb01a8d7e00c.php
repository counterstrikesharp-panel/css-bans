<!DOCTYPE html>
<html lang="en" data-mdb-theme="light">
<body>
<!-- Header -->
<?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Sidebar -->
<?php echo $__env->make('partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--Main layout-->
<main style="margin-top: 58px">
    <div class="container pt-4">
        <section>
            <div class="row">
                <div class="col-xl-4 col-sm-6 col-12 mb-4">
                    <div class="card">
                        <div class="card-body">
                            <div class="d-flex justify-content-between px-md-1">
                                <div class="align-self-center">
                                    <i class="fas fa-server text-info fa-3x"></i>
                                </div>
                                <div class="text-end">
                                    <h3>278</h3>
                                    <p class="mb-0">New Posts</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-sm-6 col-12 mb-4">
                    <div class="card">
                        <div class="card-body">
                            <div class="d-flex justify-content-between px-md-1">
                                <div class="align-self-center">
                                    <i class="fas fa-ban text-danger fa-3x"></i>
                                </div>
                                <div class="text-end">
                                    <h3>156</h3>
                                    <p class="mb-0">New Comments</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-sm-6 col-12 mb-4">
                    <div class="card">
                        <div class="card-body">
                            <div class="d-flex justify-content-between px-md-1">
                                <div class="align-self-center">
                                    <i class="fas fa-volume-mute text-success fa-3x"></i>
                                </div>
                                <div class="text-end">
                                    <h3>64.89 %</h3>
                                    <p class="mb-0">Bounce Rate</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </section>

        <section>
            <div class="row">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header text-center py-3">
                            <h5 class="mb-0 text-center">
                                <strong>Sales Performance KPIs</strong>
                            </h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-hover text-nowrap">
                                    <thead>
                                    <tr>
                                        <th scope="col"></th>
                                        <th scope="col">Product Detail Views</th>
                                        <th scope="col">Unique Purchases</th>
                                        <th scope="col">Quantity</th>
                                        <th scope="col">Product Revenue</th>
                                        <th scope="col">Avg. Price</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <th scope="row">Value</th>
                                        <td>18,492</td>
                                        <td>228</td>
                                        <td>350</td>
                                        <td>$4,787.64</td>
                                        <td>$13.68</td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Percentage change</th>
                                        <td>
                      <span class="text-danger">
                        <i class="fas fa-caret-down me-1"></i><span>-48.8%%</span>
                      </span>
                                        </td>
                                        <td>
                      <span class="text-success">
                        <i class="fas fa-caret-up me-1"></i><span>14.0%</span>
                      </span>
                                        </td>
                                        <td>
                      <span class="text-success">
                        <i class="fas fa-caret-up me-1"></i><span>46.4%</span>
                      </span>
                                        </td>
                                        <td>
                      <span class="text-success">
                        <i class="fas fa-caret-up me-1"></i><span>29.6%</span>
                      </span>
                                        </td>
                                        <td>
                      <span class="text-danger">
                        <i class="fas fa-caret-down me-1"></i><span>-11.5%</span>
                      </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Absolute change</th>
                                        <td>
                      <span class="text-danger">
                        <i class="fas fa-caret-down me-1"></i><span>-17,654</span>
                      </span>
                                        </td>
                                        <td>
                      <span class="text-success">
                        <i class="fas fa-caret-up me-1"></i><span>28</span>
                      </span>
                                        </td>
                                        <td>
                      <span class="text-success">
                        <i class="fas fa-caret-up me-1"></i><span>111</span>
                      </span>
                                        </td>
                                        <td>
                      <span class="text-success">
                        <i class="fas fa-caret-up me-1"></i><span>$1,092.72</span>
                      </span>
                                        </td>
                                        <td>
                      <span class="text-danger">
                        <i class="fas fa-caret-down me-1"></i><span>$-1.78</span>
                      </span>
                                        </td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header text-center py-3">
                            <h5 class="mb-0 text-center">
                                <strong>Sales Performance KPIs</strong>
                            </h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-hover text-nowrap">
                                    <thead>
                                    <tr>
                                        <th scope="col"></th>
                                        <th scope="col">Product Detail Views</th>
                                        <th scope="col">Unique Purchases</th>
                                        <th scope="col">Quantity</th>
                                        <th scope="col">Product Revenue</th>
                                        <th scope="col">Avg. Price</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <th scope="row">Value</th>
                                        <td>18,492</td>
                                        <td>228</td>
                                        <td>350</td>
                                        <td>$4,787.64</td>
                                        <td>$13.68</td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Percentage change</th>
                                        <td>
                      <span class="text-danger">
                        <i class="fas fa-caret-down me-1"></i><span>-48.8%%</span>
                      </span>
                                        </td>
                                        <td>
                      <span class="text-success">
                        <i class="fas fa-caret-up me-1"></i><span>14.0%</span>
                      </span>
                                        </td>
                                        <td>
                      <span class="text-success">
                        <i class="fas fa-caret-up me-1"></i><span>46.4%</span>
                      </span>
                                        </td>
                                        <td>
                      <span class="text-success">
                        <i class="fas fa-caret-up me-1"></i><span>29.6%</span>
                      </span>
                                        </td>
                                        <td>
                      <span class="text-danger">
                        <i class="fas fa-caret-down me-1"></i><span>-11.5%</span>
                      </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Absolute change</th>
                                        <td>
                      <span class="text-danger">
                        <i class="fas fa-caret-down me-1"></i><span>-17,654</span>
                      </span>
                                        </td>
                                        <td>
                      <span class="text-success">
                        <i class="fas fa-caret-up me-1"></i><span>28</span>
                      </span>
                                        </td>
                                        <td>
                      <span class="text-success">
                        <i class="fas fa-caret-up me-1"></i><span>111</span>
                      </span>
                                        </td>
                                        <td>
                      <span class="text-success">
                        <i class="fas fa-caret-up me-1"></i><span>$1,092.72</span>
                      </span>
                                        </td>
                                        <td>
                      <span class="text-danger">
                        <i class="fas fa-caret-down me-1"></i><span>$-1.78</span>
                      </span>
                                        </td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>

            </div>

        </section>



        <section class="mb-4">
            <div class="card">
                <div class="card-header text-center py-3">
                    <h5 class="mb-0 text-center">
                        <strong>Sales Performance KPIs</strong>
                    </h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover text-nowrap">
                            <thead>
                            <tr>
                                <th scope="col"></th>
                                <th scope="col">Product Detail Views</th>
                                <th scope="col">Unique Purchases</th>
                                <th scope="col">Quantity</th>
                                <th scope="col">Product Revenue</th>
                                <th scope="col">Avg. Price</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <th scope="row">Value</th>
                                <td>18,492</td>
                                <td>228</td>
                                <td>350</td>
                                <td>$4,787.64</td>
                                <td>$13.68</td>
                            </tr>
                            <tr>
                                <th scope="row">Percentage change</th>
                                <td>
                      <span class="text-danger">
                        <i class="fas fa-caret-down me-1"></i><span>-48.8%%</span>
                      </span>
                                </td>
                                <td>
                      <span class="text-success">
                        <i class="fas fa-caret-up me-1"></i><span>14.0%</span>
                      </span>
                                </td>
                                <td>
                      <span class="text-success">
                        <i class="fas fa-caret-up me-1"></i><span>46.4%</span>
                      </span>
                                </td>
                                <td>
                      <span class="text-success">
                        <i class="fas fa-caret-up me-1"></i><span>29.6%</span>
                      </span>
                                </td>
                                <td>
                      <span class="text-danger">
                        <i class="fas fa-caret-down me-1"></i><span>-11.5%</span>
                      </span>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Absolute change</th>
                                <td>
                      <span class="text-danger">
                        <i class="fas fa-caret-down me-1"></i><span>-17,654</span>
                      </span>
                                </td>
                                <td>
                      <span class="text-success">
                        <i class="fas fa-caret-up me-1"></i><span>28</span>
                      </span>
                                </td>
                                <td>
                      <span class="text-success">
                        <i class="fas fa-caret-up me-1"></i><span>111</span>
                      </span>
                                </td>
                                <td>
                      <span class="text-success">
                        <i class="fas fa-caret-up me-1"></i><span>$1,092.72</span>
                      </span>
                                </td>
                                <td>
                      <span class="text-danger">
                        <i class="fas fa-caret-down me-1"></i><span>$-1.78</span>
                      </span>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </section>

    </div>
</main>
<!-- Footer -->
<?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- MDB -->
<?php echo app('Illuminate\Foundation\Vite')(['resources/js/mdb.umd.min.js']); ?>
<!-- Custom scripts -->
<?php echo app('Illuminate\Foundation\Vite')(['resources/js/admin.js']); ?>
</body>
</html>
<?php /**PATH /home/ubuntu/css-bans/resources/views/welcome.blade.php ENDPATH**/ ?>