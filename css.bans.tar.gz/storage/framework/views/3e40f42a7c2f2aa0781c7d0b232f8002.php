<!-- resources/views/components/alert.blade.php -->

<div class="alert alert-<?php echo e($type); ?> alert-dismissible fade show" role="alert">
    <?php echo e($message); ?>

    <button type="button" class="close alert-close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>
<?php /**PATH /home/ubuntu/css-bans/resources/views/components/alert.blade.php ENDPATH**/ ?>