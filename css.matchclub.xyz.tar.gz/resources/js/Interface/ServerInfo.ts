export interface ServerInfo {
    id: number,
    name: string;
    players: string;
    ip: string;
    port: string;
    map: string;
    connect_button: string;
}
