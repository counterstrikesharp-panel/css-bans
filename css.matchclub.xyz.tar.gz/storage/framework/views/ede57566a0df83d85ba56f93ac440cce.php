<hr class="hr" />
<footer class="text-center">
    <!-- Copyright -->
    <div class="text-center">
        <a
            data-mdb-ripple-init
            class="btn text-white btn-floating m-1"
            style="background-color: #333333;"
            href="https://github.com/hobsRKM/css-bans"
            role="button"
        >
            <i class="fab fa-github"></i>
        </a>
       <span style="display: block"> © <?php echo e(date('Y')); ?> Copyright
        <a class="text-body" style="color: #ff0000  !important" href="https://github.com/hobsRKM/css-bans">css-bans.in</a>
       </span>

    </div>
    <!-- Copyright -->
</footer>
<?php /**PATH /www/wwwroot/css.matchclub.xyz/resources/views/partials/footer.blade.php ENDPATH**/ ?>