<div style="height: 400px; overflow-y: auto;">
    <table class="table">
        <thead>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Frags</th>
            <th>Time</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($player['Name']); ?></td>
                <td><?php echo e($player['Frags']); ?></td>
                <td><?php echo e($player['TimeF']); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH /www/wwwroot/css.matchclub.xyz/resources/views/admin/servers/players.blade.php ENDPATH**/ ?>