<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card shadow">
                <div class="card-body">
                    <h5 class="card-title text-center mb-4">Edit Admin</h5>
                    <form action="<?php echo e(route('admin.update', ['player_steam' => $admin->first()->player_steamid])); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <!-- Server Dropdown -->
                        <div data-mdb-input-init class="form-outline mb-3">
                            <label class="form-label" for="server_id"><b>Server</b></label>
                            <select  class="form-select" id="server_id" name="server_id" required>
                                <option value="">Select Server</option>
                                <?php $__currentLoopData = $servers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $server): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($server->id); ?>" <?php echo e($server->id == $admin->first()->server_id ? 'selected' : ''); ?>>
                                        <?php echo e($server->hostname); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <!-- Permissions Checkboxes -->
                        <div class="mb-3">
                            <label><b>Permissions</b></label><br>
                                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="permissions[]" value="<?php echo e($permission->permission); ?>" id="permission<?php echo e($permission->id); ?>"

                                        <?php echo e(in_array($permission->permission, $adminPermissions) ? 'checked' : ''); ?>>
                                    <label class="form-check-label" for="permission<?php echo e($permission->id); ?>">
                                        <?php echo e($permission->description); ?> (<?php echo e($permission->permission); ?>)
                                    </label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <!-- Ends On -->
                        <div data-mdb-input-init class="form-outline mb-3">
                            <label for="ends"><b>Ends On</b></label>
                            <input type="date" id="ends" name="ends" class="form-control" value="<?php echo e(date('Y-m-d', strtotime($admin->first()->ends))); ?>" required>
                        </div>

                        <div class="text-center">
                            <button type="submit" class="btn btn-primary">Update Admin</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/js/admin/edit.ts']); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ubuntu/css-bans/resources/views/admin/admins/edit.blade.php ENDPATH**/ ?>