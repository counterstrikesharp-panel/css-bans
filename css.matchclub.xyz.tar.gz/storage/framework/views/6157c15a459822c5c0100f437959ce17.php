<?php
 ?><?php /**PATH /home/ubuntu/css-bans/resources/views/partials/footer.blade.php ENDPATH**/ ?>