<script
    src="https://code.jquery.com/jquery-3.7.1.min.js"
    integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo="
    crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/3.0.0/mdb.min.js"></script>
<?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js']); ?>

<script>
    const serversListUrl = '<?php echo env('VITE_SITE_DIR'); ?>/servers';
    const mutesListUrl = '<?php echo env('VITE_SITE_DIR'); ?>/mutes';
    const bansListUrl = '<?php echo env('VITE_SITE_DIR'); ?>/bans';
    const adminListUrl = '<?php echo env('VITE_SITE_DIR'); ?>/list/admins';
    const banListUrl = '<?php echo env('VITE_SITE_DIR'); ?>/list/bans';
</script>



<?php /**PATH /www/wwwroot/css.matchclub.xyz/resources/views/partials/scripts.blade.php ENDPATH**/ ?>